//
// Created by Rena on 5/25/21.
//

#include "asset.h"
sf::Font asset::fontForS;
bool asset::fontLoader;