//
// Created by Rena on 5/27/21.
//

#ifndef FIRSTDRAFT_STATE_H
#define FIRSTDRAFT_STATE_H


enum State{
    HIDDEN,
    NONHIDDEN,
    HIGHLIGHTED,
    DISABLED,
    BITNKON,
    BINKOFF,
    LASTSTATE
};



#endif //FIRSTDRAFT_STATE_H
